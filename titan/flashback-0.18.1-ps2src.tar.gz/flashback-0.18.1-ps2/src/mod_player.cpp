/* REminiscence - Flashback interpreter
 * Copyright (C) 2005 Gregory Montoir
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <cmath>
#include "file.h"
#include "mixer.h"
#include "mod_player.h"


ModPlayer::ModPlayer(const char *dataPath)
	: _playing(false), _dataPath(dataPath), _music(NULL) {
}

void ModPlayer::play(uint8 num) {
	if (!_playing && num < _modulesFilesCount) {
		File f;
		bool found = false;
		for (uint8 i = 0; i < ARRAYSIZE(_modulesFiles[num]); ++i) {
			if (f.open(_modulesFiles[num][i], _dataPath, "rb")) {
				found = true;
				break;
			}
		}
		if (!found) {
			warning("Can't find music file %d", num);
		} else {
			// gawd
			char *dummy = (char *)malloc(f.size());
			f.read(dummy, f.size());
			SDL_RWops *rw = SDL_RWFromMem(dummy, f.size());
			_music = Mix_LoadMUS_RW(rw);
			free(dummy);
			if (_music != NULL)
			{
				Mix_PlayMusic(_music, -1);
			}

			_playing = true;
		}
	}
}

void ModPlayer::stop() {
	if (_playing) {
		Mix_HaltMusic();

		if (_music != NULL) {
			Mix_FreeMusic(_music);
			_music = 0;
		}

		_playing = false;
	}
}

