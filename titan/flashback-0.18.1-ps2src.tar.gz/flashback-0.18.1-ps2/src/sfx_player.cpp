/* REminiscence - Flashback interpreter
 * Copyright (C) 2005 Gregory Montoir
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
#include "mixer.h"
#include "sfx_player.h"
#include <SDL_Mixer.h>

SfxPlayer::SfxPlayer()
	: _mod(0), _playing(false) {
}

void SfxPlayer::play(uint8 num) {
	debug(DBG_SFX, "SfxPlayer::play(%d)", num);
	if (!_playing) {
		if (num >= 68 && num <= 75) {
			static const Module *modTable[] = {
				&_module68, &_module68, &_module70, &_module70,
				&_module72, &_module73, &_module74, &_module75
			};
			_mod = modTable[num - 68];
			_curOrder = 0;
			_numOrders = READ_BE_UINT16(_mod->moduleData);
			_orderDelay = 0;
			_modData = _mod->moduleData + 0x22;
			memset(_samples, 0, sizeof(_samples));
			_samplesLeft = 0;
			//_mix->setPremixHook(mixCallback, this);
			_playing = true;
		}
	}
}

void SfxPlayer::stop() {
	if (_playing) {
		//_mix->setPremixHook(0, 0);
		_playing = false;
	}
}

void SfxPlayer::playSample(int channel, const uint8 *sampleData, uint16 period) {
	assert(channel < NUM_CHANNELS);
	SampleInfo *si = &_samples[channel];
	si->len = READ_BE_UINT16(sampleData); sampleData += 2;
	si->vol = READ_BE_UINT16(sampleData); sampleData += 2;
	si->loopPos = READ_BE_UINT16(sampleData); sampleData += 2;
	si->loopLen = READ_BE_UINT16(sampleData); sampleData += 2;
	si->freq = PAULA_FREQ / period;
	si->pos = 0;
	si->data = sampleData;
}
